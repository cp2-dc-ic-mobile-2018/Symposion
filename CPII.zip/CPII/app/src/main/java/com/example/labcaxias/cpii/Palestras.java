package com.example.labcaxias.cpii;

import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Palestras extends Activity {
    List<String> palestras;
    ArrayAdapter<String> adaptador;
    ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_palestras);
        lista = (ListView) findViewById(R.id.lista);
        palestras = new ArrayList<String>();
        adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, palestras);
        lista.setAdapter(adaptador);
        palestras.add("Palestra: NVIDIA\nAssunto: Conhecendo o NVIDIA\nDuração:1h15min\nInicio:9:00\nLocal:Roxinho\nLimite: 45 pessoas\nPalestrante: Pedro Mário Cruz");
        palestras.add("Palestra: Visualização De Dados\nAssunto: Representação de dados\nDuração:1h15min\nInicio:9:00\nLocal:Salão Nobre\nLimite: 30 pessoas\nPalestrante: Professor boladão do github");
    }

}
